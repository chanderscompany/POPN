var NAVTREE =
[
  [ "libusbK", "index.html", [
    [ "libusbK Home", "index.html", [
      [ "About", "usbk_about.html", null ],
      [ "libusbK.sys Comparisons", "usbk_comparisons.html", null ],
      [ "Installation", "usbk_installing.html", null ],
      [ "Using the Library", "usbk_usage.html", null ],
      [ "Building from source", "usbk_building.html", [
        [ "Building with make.cmd", "usbk_building_make_cmd.html", null ],
        [ "Building with WDK", "usbk_building_wdk.html", null ],
        [ "Building with MSVC", "usbk_building_msvc.html", null ]
      ] ],
      [ "Creating Client Installers With InfWizard", "usbk_installers.html", null ],
      [ "Support Forum", "usbk_mailing_list.html", null ],
      [ "Power Management", "usbk_power_management.html", null ],
      [ "Pipe Policy Management", "usbk_pipe_management.html", null ]
    ] ],
    [ "API Reference", "modules.html", [
      [ "USB General", "group__libk.html", [
        [ "Defines", "group__libk.html", [
          [ "USB_ENDPOINT_DIRECTION_OUT", "group__libk.html#gaeddc90e6827404f37b241ee11800d264", null ],
          [ "USB_ENDPOINT_DIRECTION_IN", "group__libk.html#ga3ada066cc9ad5200079430e6e39bbbff", null ]
        ] ],
        [ "Enumerations", "group__libk.html", [
          [ "KLIB_HANDLE_TYPE", "group__libk.html#ga146d70d77a014ea0fceb382dfa704938", null ],
          [ "BMREQUEST_TYPE", "group__libk.html#ga49382597530eef092420ca514fd6c299", null ],
          [ "BMREQUEST_RECIPIENT", "group__libk.html#gae66f21f1bbac1d674315d7f2f55a2990", null ],
          [ "USB_GETSTATUS", "group__libk.html#ga02cd22e5e128dc07cb6677440dbfac0b", null ],
          [ "USB_DESCRIPTOR_TYPE", "group__libk.html#ga3cf672bafe6e874ecd20e0f9d647328a", null ],
          [ "USB_CONFIG_BM_ATTRIBUTE_ENUM", "group__libk.html#gab48934d49e9de0a926d380f193fc8560", null ],
          [ "USB_REQUEST_ENUM", "group__libk.html#gaf209ab34dbd779fd41e87fe62e91112a", null ],
          [ "USB_DEVICE_CLASS_ENUM", "group__libk.html#ga4e49077653bcc1ffa364275ca28d1a04", null ],
          [ "KUSB_PROPERTY", "group__libk.html#gaf2273f433f17e475d5b762123b79fc12", null ],
          [ "KUSB_DRVID", "group__libk.html#gaaea7b3ca95ed6c86c533c5e3328466bd", null ],
          [ "KUSB_FNID", "group__libk.html#ga8a86fa7b1ae765cc000d9c4c5abc9146", null ]
        ] ],
        [ "Functions", "group__libk.html", [
          [ "LibK_GetVersion", "group__libk.html#ga0bd85c166423986cd8d58ff3fd32482a", null ],
          [ "LibK_GetContext", "group__libk.html#gad66eb26467fba92c3d574cceee8b6fe8", null ],
          [ "LibK_SetContext", "group__libk.html#gad16bfd67915d14f9767d6d3d5a6ffeda", null ],
          [ "LibK_SetCleanupCallback", "group__libk.html#ga1dd59caf260f94494360cac67a334652", null ],
          [ "LibK_LoadDriverAPI", "group__libk.html#gab9ce93038cc7eefa19ff7e964b935bb6", null ],
          [ "LibK_CopyDriverAPI", "group__libk.html#ga1be463d66d7a468811d97bb8f101ada6", null ],
          [ "LibK_GetProcAddress", "group__libk.html#gad85a16d2edde27c1e42bbe715fe3dc9c", null ],
          [ "LibK_SetDefaultContext", "group__libk.html#ga0aaaa3df6661edf7ed77e55f220f78cf", null ],
          [ "LibK_GetDefaultContext", "group__libk.html#ga65deb23d5d57eaaa37b70c9ef98a64da", null ],
          [ "LibK_Context_Init", "group__libk.html#ga9174be968f48056fc2e5f79fea6333c8", null ],
          [ "LibK_Context_Free", "group__libk.html#gaaead38411e38782e28681ab9a3409a81", null ]
        ] ],
        [ "Data Structures", "group__libk.html", [
          [ "KUSB_SETUP_PACKET", "union_k_u_s_b___s_e_t_u_p___p_a_c_k_e_t.html", null ],
          [ "KLIB_VERSION", "struct_k_l_i_b___v_e_r_s_i_o_n.html", null ],
          [ "USB_DEVICE_DESCRIPTOR", "struct_u_s_b___d_e_v_i_c_e___d_e_s_c_r_i_p_t_o_r.html", null ],
          [ "USB_ENDPOINT_DESCRIPTOR", "struct_u_s_b___e_n_d_p_o_i_n_t___d_e_s_c_r_i_p_t_o_r.html", null ],
          [ "USB_CONFIGURATION_DESCRIPTOR", "struct_u_s_b___c_o_n_f_i_g_u_r_a_t_i_o_n___d_e_s_c_r_i_p_t_o_r.html", null ],
          [ "USB_INTERFACE_DESCRIPTOR", "struct_u_s_b___i_n_t_e_r_f_a_c_e___d_e_s_c_r_i_p_t_o_r.html", null ],
          [ "USB_STRING_DESCRIPTOR", "struct_u_s_b___s_t_r_i_n_g___d_e_s_c_r_i_p_t_o_r.html", null ],
          [ "USB_COMMON_DESCRIPTOR", "struct_u_s_b___c_o_m_m_o_n___d_e_s_c_r_i_p_t_o_r.html", null ],
          [ "USB_INTERFACE_ASSOCIATION_DESCRIPTOR", "struct_u_s_b___i_n_t_e_r_f_a_c_e___a_s_s_o_c_i_a_t_i_o_n___d_e_s_c_r_i_p_t_o_r.html", null ],
          [ "KUSB_DRIVER_API_INFO", "struct_k_u_s_b___d_r_i_v_e_r___a_p_i___i_n_f_o.html", null ],
          [ "KUSB_DRIVER_API", "struct_k_u_s_b___d_r_i_v_e_r___a_p_i.html", null ]
        ] ]
      ] ],
      [ "USB Core", "group__usbk.html", [
        [ "Functions", "group__usbk.html", [
          [ "UsbK_Init", "group__usbk.html#ga24a8fe59aa989831088cd117a612765b", null ],
          [ "UsbK_Free", "group__usbk.html#ga3a4dcea8493972399636b67f06616a99", null ],
          [ "UsbK_ClaimInterface", "group__usbk.html#gaf183a80a0cad612e6b46e39fa7e34539", null ],
          [ "UsbK_ReleaseInterface", "group__usbk.html#gaf57deed79fef9731b93c1b1775fe1897", null ],
          [ "UsbK_SetAltInterface", "group__usbk.html#gaca0a83530cab1fde69ca8ab1de7ac09f", null ],
          [ "UsbK_GetAltInterface", "group__usbk.html#gadd99fdb88683db180b192eea4170fddd", null ],
          [ "UsbK_GetDescriptor", "group__usbk.html#ga8ff56d3d3faceea937e76f926007e0d6", null ],
          [ "UsbK_ControlTransfer", "group__usbk.html#gadb7ffd96c101273204c909c6e5d0c6d1", null ],
          [ "UsbK_SetPowerPolicy", "group__usbk.html#gadc938a613b1d64f7bba4ddc53591d317", null ],
          [ "UsbK_GetPowerPolicy", "group__usbk.html#ga46b0bd1307f86635beb0f9ff5421b4e3", null ],
          [ "UsbK_SetConfiguration", "group__usbk.html#ga15fbe8621910393b1083c48c7e69a8d8", null ],
          [ "UsbK_GetConfiguration", "group__usbk.html#ga54236c2c9c8d2ae8e7c0b5bcc54bf172", null ],
          [ "UsbK_ResetDevice", "group__usbk.html#gadc104b364aa02e4fd256e88a56d7911c", null ],
          [ "UsbK_Initialize", "group__usbk.html#gaaa762e1d43c4820e005cbac3e9b94228", null ],
          [ "UsbK_SelectInterface", "group__usbk.html#ga051f34275b436549b1a5fb40590c3f5a", null ],
          [ "UsbK_GetAssociatedInterface", "group__usbk.html#ga0bc1c19497a63cb2eddd86d2b9f15313", null ],
          [ "UsbK_Clone", "group__usbk.html#gad8f65e3afedd5ec44de4978130cbaa36", null ],
          [ "UsbK_QueryInterfaceSettings", "group__usbk.html#ga8d4b2f831dfeeaf7a472e323d5097ff1", null ],
          [ "UsbK_QueryDeviceInformation", "group__usbk.html#ga135fc68a555f24595adeeeccd9af11d8", null ],
          [ "UsbK_SetCurrentAlternateSetting", "group__usbk.html#ga89191839025460c02702587c660d9a85", null ],
          [ "UsbK_GetCurrentAlternateSetting", "group__usbk.html#ga6379112f5962f53d27f0d2cf9a2357df", null ],
          [ "UsbK_QueryPipe", "group__usbk.html#gaf3aa032c6c600555420e25f84ed90ed6", null ],
          [ "UsbK_SetPipePolicy", "group__usbk.html#ga10f9e367e4241c431edc2cecd1bb827e", null ],
          [ "UsbK_GetPipePolicy", "group__usbk.html#ga60cfaffb966eefea13a378c9342408a9", null ],
          [ "UsbK_ReadPipe", "group__usbk.html#ga975f879ca9864c5b3190075683e2b389", null ],
          [ "UsbK_WritePipe", "group__usbk.html#ga9bb3e86033f5af3f25b7d13337856a2c", null ],
          [ "UsbK_ResetPipe", "group__usbk.html#ga5adec045f30c9b5e92c9fce441c826ca", null ],
          [ "UsbK_AbortPipe", "group__usbk.html#gab109ea96a41f43b23c5d743db11bc34d", null ],
          [ "UsbK_FlushPipe", "group__usbk.html#ga06de8ffa774250be7124bf95641408c8", null ],
          [ "UsbK_IsoReadPipe", "group__usbk.html#ga5f8bd18c406ba04c961a845f84b93b1d", null ],
          [ "UsbK_IsoWritePipe", "group__usbk.html#ga01747052ea7f310db7dfccc5a5bf92b4", null ],
          [ "UsbK_GetCurrentFrameNumber", "group__usbk.html#ga6e086713a3484dd6a77c32c4adfa3e88", null ],
          [ "UsbK_GetOverlappedResult", "group__usbk.html#gab134dea13044b6a38375aef9a79d57e2", null ],
          [ "UsbK_GetProperty", "group__usbk.html#ga295b1e10064873344d557622c734c02a", null ]
        ] ]
      ] ],
      [ "Device List", "group__lstk.html", [
        [ "Typedefs", "group__lstk.html", [
          [ "KLST_ENUM_DEVINFO_CB", "group__lstk.html#ga7829b122705ec85e6b69ffff97bc466a", null ]
        ] ],
        [ "Enumerations", "group__lstk.html", [
          [ "KLST_SYNC_FLAG", "group__lstk.html#gadd38540029cc45225061ce557fcb9643", null ],
          [ "KLST_FLAG", "group__lstk.html#ga012bbc8e5b32e3bbe52aad9f12fd1ad1", null ]
        ] ],
        [ "Functions", "group__lstk.html", [
          [ "LstK_Init", "group__lstk.html#gae80b0756eac90d3d69abce3c23f8bed5", null ],
          [ "LstK_InitEx", "group__lstk.html#gaf17580866478e6bf25a47cff596f2092", null ],
          [ "LstK_Free", "group__lstk.html#ga922ee5dca10da572eb5d1b8d2cf9f45c", null ],
          [ "LstK_Enumerate", "group__lstk.html#ga6e2189fe48fb5244057bcf81ba05d989", null ],
          [ "LstK_Current", "group__lstk.html#ga9784ff4566aeb5ccdce26e67df5a4ae7", null ],
          [ "LstK_MoveNext", "group__lstk.html#gabe77bdadf4448e1cb1d8ca37fff1a981", null ],
          [ "LstK_MoveReset", "group__lstk.html#gacfa3930a67ecda1f1cc8986ce06fe46e", null ],
          [ "LstK_FindByVidPid", "group__lstk.html#ga53c16a1e9d0fc993e53bc9feb6f3260c", null ],
          [ "LstK_Count", "group__lstk.html#ga9d2221bdf53c7133f837285b398622a7", null ]
        ] ],
        [ "Data Structures", "group__lstk.html", [
          [ "KLST_DEV_COMMON_INFO", "struct_k_l_s_t___d_e_v___c_o_m_m_o_n___i_n_f_o.html", null ],
          [ "KLST_DEVINFO", "struct_k_l_s_t___d_e_v_i_n_f_o.html", null ],
          [ "KLST_PATTERN_MATCH", "struct_k_l_s_t___p_a_t_t_e_r_n___m_a_t_c_h.html", null ]
        ] ]
      ] ],
      [ "Overlapped I/O", "group__ovlk.html", [
        [ "Enumerations", "group__ovlk.html", [
          [ "KOVL_WAIT_FLAG", "group__ovlk.html#ga1c900de01c552e12402b205176d269e7", null ],
          [ "KOVL_POOL_FLAG", "group__ovlk.html#ga175828e2e3d7e392bab64a34df49dbdf", null ]
        ] ],
        [ "Functions", "group__ovlk.html", [
          [ "OvlK_Acquire", "group__ovlk.html#gadc56cb21f2bc2e0935d69ac8733892ff", null ],
          [ "OvlK_Release", "group__ovlk.html#gab9d631aa236af38165dd8d471276be8a", null ],
          [ "OvlK_Init", "group__ovlk.html#gad8e63f8be4e00d4dad7e1c09138a5195", null ],
          [ "OvlK_Free", "group__ovlk.html#ga68c4aabfb5039bfb910101ceee557228", null ],
          [ "OvlK_GetEventHandle", "group__ovlk.html#ga72c8f6976876f3e9d3eda00cea966239", null ],
          [ "OvlK_Wait", "group__ovlk.html#ga68befdb564a625ad80203cf41a260422", null ],
          [ "OvlK_WaitOldest", "group__ovlk.html#ga9afe359a27c151e84f50edf50cda3a1a", null ],
          [ "OvlK_WaitOrCancel", "group__ovlk.html#ga609de4416d69e79fa5bf4434b262104a", null ],
          [ "OvlK_WaitAndRelease", "group__ovlk.html#ga2a7e544149c7b0dec5d576eef3c80bc1", null ],
          [ "OvlK_IsComplete", "group__ovlk.html#ga39502293d15b12eaafbb096bc4a0630d", null ],
          [ "OvlK_ReUse", "group__ovlk.html#ga9ac570a5ffcd0080528ad64792922083", null ]
        ] ]
      ] ],
      [ "Hotplug Event Notifier", "group__hotk.html", [
        [ "Enumerations", "group__hotk.html", [
          [ "KHOT_FLAG", "group__hotk.html#ga61d57be186b1384430cefc8eaa9edc2c", null ]
        ] ],
        [ "Functions", "group__hotk.html", [
          [ "HotK_Init", "group__hotk.html#ga0c555272bc4d4691aa8bef3242d0472e", null ],
          [ "HotK_Free", "group__hotk.html#ga3a0a636aee423ee1bcd02b4431fa8e76", null ]
        ] ],
        [ "Data Structures", "group__hotk.html", [
          [ "KHOT_PARAMS", "struct_k_h_o_t___p_a_r_a_m_s.html", null ]
        ] ]
      ] ],
      [ "Pipe Stream", "group__stmk.html", [
        [ "Enumerations", "group__stmk.html", [
          [ "KSTM_FLAG", "group__stmk.html#gaddb51beaad331fad164d745287be75e4", null ],
          [ "KSTM_COMPLETE_RESULT", "group__stmk.html#gaa31dabc758d7072425242a759886c0b3", null ]
        ] ],
        [ "Functions", "group__stmk.html", [
          [ "StmK_Init", "group__stmk.html#ga4bfc2b0cdd871eef4c3769e70aa8407b", null ],
          [ "StmK_Free", "group__stmk.html#ga5288b696be1d552909005bf2c4b75760", null ],
          [ "StmK_Start", "group__stmk.html#ga9b22a5927e609cfee07e8e519219884e", null ],
          [ "StmK_Stop", "group__stmk.html#ga4202f6f3caec7c10466b86776c83548b", null ],
          [ "StmK_Read", "group__stmk.html#ga67fbbaa99de8db41c093dee0dae41653", null ],
          [ "StmK_Write", "group__stmk.html#gace9342a3b724b6a1ae7f06eb5e0a1c98", null ],
          [ "KSTM_BEFORE_COMPLETE_CB", "group__stmk.html#gac723c63ef884d146869087dbf2c1bad5", null ]
        ] ],
        [ "Data Structures", "group__stmk.html", [
          [ "KSTM_XFER_CONTEXT", "struct_k_s_t_m___x_f_e_r___c_o_n_t_e_x_t.html", null ],
          [ "KSTM_INFO", "struct_k_s_t_m___i_n_f_o.html", null ],
          [ "KSTM_CALLBACK", "struct_k_s_t_m___c_a_l_l_b_a_c_k.html", null ]
        ] ]
      ] ],
      [ "Advanced ISO", "group__isok.html", [
        [ "Enumerations", "group__isok.html", [
          [ "KISO_FLAG", "group__isok.html#ga3dfcc97ea167c5964ce2c5102cd89670", null ]
        ] ],
        [ "Functions", "group__isok.html", [
          [ "IsoK_Init", "group__isok.html#gab8e728f8ae21bfb23ee6bd543a8602fd", null ],
          [ "IsoK_Free", "group__isok.html#ga6e5c7d077b16d81afc4937d8ee9e0b41", null ],
          [ "IsoK_SetPackets", "group__isok.html#gacfe64765804927645bf4042c00fdc437", null ],
          [ "IsoK_SetPacket", "group__isok.html#gabf5bb04a2aed4c7af86a62cfa98f3cb8", null ],
          [ "IsoK_GetPacket", "group__isok.html#gad376fa1ded3e75454ced368d36b56545", null ],
          [ "IsoK_EnumPackets", "group__isok.html#ga4e6d69df60acfc36672d6a5153fb4293", null ],
          [ "IsoK_ReUse", "group__isok.html#ga911f7d61886b4e137db24277fb62a08d", null ]
        ] ],
        [ "Data Structures", "group__isok.html", [
          [ "KISO_PACKET", "struct_k_i_s_o___p_a_c_k_e_t.html", null ],
          [ "KISO_CONTEXT", "struct_k_i_s_o___c_o_n_t_e_x_t.html", null ]
        ] ]
      ] ]
    ] ],
    [ "Data Structures", "annotated.html", [
      [ "KHOT_PARAMS", "struct_k_h_o_t___p_a_r_a_m_s.html", null ],
      [ "KISO_CONTEXT", "struct_k_i_s_o___c_o_n_t_e_x_t.html", null ],
      [ "KISO_PACKET", "struct_k_i_s_o___p_a_c_k_e_t.html", null ],
      [ "KLIB_VERSION", "struct_k_l_i_b___v_e_r_s_i_o_n.html", null ],
      [ "KLST_DEV_COMMON_INFO", "struct_k_l_s_t___d_e_v___c_o_m_m_o_n___i_n_f_o.html", null ],
      [ "KLST_DEVINFO", "struct_k_l_s_t___d_e_v_i_n_f_o.html", null ],
      [ "KLST_PATTERN_MATCH", "struct_k_l_s_t___p_a_t_t_e_r_n___m_a_t_c_h.html", null ],
      [ "KSTM_CALLBACK", "struct_k_s_t_m___c_a_l_l_b_a_c_k.html", null ],
      [ "KSTM_INFO", "struct_k_s_t_m___i_n_f_o.html", null ],
      [ "KSTM_XFER_CONTEXT", "struct_k_s_t_m___x_f_e_r___c_o_n_t_e_x_t.html", null ],
      [ "KUSB_DRIVER_API", "struct_k_u_s_b___d_r_i_v_e_r___a_p_i.html", null ],
      [ "KUSB_DRIVER_API_INFO", "struct_k_u_s_b___d_r_i_v_e_r___a_p_i___i_n_f_o.html", null ],
      [ "KUSB_SETUP_PACKET", "union_k_u_s_b___s_e_t_u_p___p_a_c_k_e_t.html", null ],
      [ "USB_COMMON_DESCRIPTOR", "struct_u_s_b___c_o_m_m_o_n___d_e_s_c_r_i_p_t_o_r.html", null ],
      [ "USB_CONFIGURATION_DESCRIPTOR", "struct_u_s_b___c_o_n_f_i_g_u_r_a_t_i_o_n___d_e_s_c_r_i_p_t_o_r.html", null ],
      [ "USB_DEVICE_DESCRIPTOR", "struct_u_s_b___d_e_v_i_c_e___d_e_s_c_r_i_p_t_o_r.html", null ],
      [ "USB_ENDPOINT_DESCRIPTOR", "struct_u_s_b___e_n_d_p_o_i_n_t___d_e_s_c_r_i_p_t_o_r.html", null ],
      [ "USB_INTERFACE_ASSOCIATION_DESCRIPTOR", "struct_u_s_b___i_n_t_e_r_f_a_c_e___a_s_s_o_c_i_a_t_i_o_n___d_e_s_c_r_i_p_t_o_r.html", null ],
      [ "USB_INTERFACE_DESCRIPTOR", "struct_u_s_b___i_n_t_e_r_f_a_c_e___d_e_s_c_r_i_p_t_o_r.html", null ],
      [ "USB_STRING_DESCRIPTOR", "struct_u_s_b___s_t_r_i_n_g___d_e_s_c_r_i_p_t_o_r.html", null ],
      [ "WINUSB_PIPE_INFORMATION", "struct_w_i_n_u_s_b___p_i_p_e___i_n_f_o_r_m_a_t_i_o_n.html", null ],
      [ "WINUSB_SETUP_PACKET", "struct_w_i_n_u_s_b___s_e_t_u_p___p_a_c_k_e_t.html", null ]
    ] ],
    [ "Data Structure Index", "classes.html", null ],
    [ "Data Fields", "functions.html", null ],
    [ "File List", "files.html", [
      [ "examples.h", "examples_8h.html", null ],
      [ "libusbk.h", "libusbk_8h.html", null ],
      [ "lusbk_shared.h", "lusbk__shared_8h.html", null ]
    ] ],
    [ "Examples", "examples.html", [
      [ "config-interface.c", "config-interface_8c-example.html", null ],
      [ "hot-plug-monitor.c", "hot-plug-monitor_8c-example.html", null ],
      [ "load-driver-api.c", "load-driver-api_8c-example.html", null ],
      [ "open-device.c", "open-device_8c-example.html", null ],
      [ "pipe-policy-other.c", "pipe-policy-other_8c-example.html", null ],
      [ "pipe-policy-timeout.c", "pipe-policy-timeout_8c-example.html", null ],
      [ "power-policy-suspend.c", "power-policy-suspend_8c-example.html", null ],
      [ "show-device.c", "show-device_8c-example.html", null ],
      [ "xfer-async-loop.c", "xfer-async-loop_8c-example.html", null ],
      [ "xfer-async.c", "xfer-async_8c-example.html", null ],
      [ "xfer-control.c", "xfer-control_8c-example.html", null ],
      [ "xfer-iso-read.c", "xfer-iso-read_8c-example.html", null ],
      [ "xfer-iso.c", "xfer-iso_8c-example.html", null ],
      [ "xfer-stream.c", "xfer-stream_8c-example.html", null ],
      [ "xfer-sync.c", "xfer-sync_8c-example.html", null ]
    ] ],
    [ "Globals", "globals.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

