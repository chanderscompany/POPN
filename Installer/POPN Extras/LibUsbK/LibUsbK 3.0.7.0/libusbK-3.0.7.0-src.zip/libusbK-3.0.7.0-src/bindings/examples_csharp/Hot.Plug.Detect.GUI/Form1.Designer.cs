﻿namespace Hot.Plug.Detect.GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvDevices = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.colSymbolicLink = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDeviceDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colInstanceID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDevices)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvDevices
            // 
            this.dgvDevices.AllowUserToAddRows = false;
            this.dgvDevices.AllowUserToDeleteRows = false;
            this.dgvDevices.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDevices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDevices.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSymbolicLink,
            this.colDeviceDesc,
            this.colInstanceID});
            this.dgvDevices.Location = new System.Drawing.Point(12, 38);
            this.dgvDevices.MultiSelect = false;
            this.dgvDevices.Name = "dgvDevices";
            this.dgvDevices.ReadOnly = true;
            this.dgvDevices.RowHeadersVisible = false;
            this.dgvDevices.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDevices.ShowEditingIcon = false;
            this.dgvDevices.Size = new System.Drawing.Size(419, 179);
            this.dgvDevices.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Connected Devices:";
            // 
            // colSymbolicLink
            // 
            this.colSymbolicLink.HeaderText = "SymbolicLink";
            this.colSymbolicLink.Name = "colSymbolicLink";
            this.colSymbolicLink.ReadOnly = true;
            this.colSymbolicLink.Visible = false;
            // 
            // colDeviceDesc
            // 
            this.colDeviceDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colDeviceDesc.HeaderText = "Name";
            this.colDeviceDesc.Name = "colDeviceDesc";
            this.colDeviceDesc.ReadOnly = true;
            // 
            // colInstanceID
            // 
            this.colInstanceID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colInstanceID.HeaderText = "Instance ID";
            this.colInstanceID.Name = "colInstanceID";
            this.colInstanceID.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 229);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvDevices);
            this.Name = "Form1";
            this.Text = "Hot Plug Detection GUI Example";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDevices)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDevices;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSymbolicLink;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDeviceDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn colInstanceID;

    }
}

